Thank you for get this typeface! 
 
If you want to donate or make contact,
please don't doubt it. Write me to david.ignorant@gmail.com or d.espinosa.mar@gmail.com

THIS IS NOT A FREE FONT.

Copyright 2014. Type Sailor - David Espinosa. Just for personal use.
